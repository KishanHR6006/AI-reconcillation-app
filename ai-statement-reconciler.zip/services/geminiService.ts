
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { ReconciliationResult } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        summary: {
            type: Type.OBJECT,
            properties: {
                matchedCount: { type: Type.INTEGER, description: "Total number of matched transactions." },
                tallyOnlyCount: { type: Type.INTEGER, description: "Total number of transactions found only in the Tally statement." },
                bankOnlyCount: { type: Type.INTEGER, description: "Total number of transactions found only in the Bank statement." },
                totalMatchedAmount: { type: Type.NUMBER, description: "Sum of amounts for all matched transactions." }
            },
            required: ["matchedCount", "tallyOnlyCount", "bankOnlyCount", "totalMatchedAmount"]
        },
        matchedTransactions: {
            type: Type.ARRAY,
            description: "A list of transactions that appear in both statements.",
            items: {
                type: Type.OBJECT,
                properties: {
                    date: { type: Type.STRING, description: "Date of the transaction (e.g., 'YYYY-MM-DD')." },
                    description: { type: Type.STRING, description: "Description or particulars of the transaction." },
                    amount: { type: Type.NUMBER, description: "The transaction amount." }
                },
                required: ["date", "description", "amount"]
            }
        },
        tallyOnlyTransactions: {
            type: Type.ARRAY,
            description: "A list of transactions that appear only in the Tally statement.",
            items: {
                type: Type.OBJECT,
                properties: {
                    date: { type: Type.STRING, description: "Date of the transaction." },
                    description: { type: Type.STRING, description: "Description of the transaction." },
                    amount: { type: Type.NUMBER, description: "The transaction amount." }
                },
                required: ["date", "description", "amount"]
            }
        },
        bankOnlyTransactions: {
            type: Type.ARRAY,
            description: "A list of transactions that appear only in the bank statement.",
            items: {
                type: Type.OBJECT,
                properties: {
                    date: { type: Type.STRING, description: "Date of the transaction." },
                    description: { type: Type.STRING, description: "Description of the transaction." },
                    amount: { type: Type.NUMBER, description: "The transaction amount." }
                },
                required: ["date", "description", "amount"]
            }
        }
    },
    required: ["summary", "matchedTransactions", "tallyOnlyTransactions", "bankOnlyTransactions"]
};


export const reconcileStatements = async (tallyFile: File, bankFile: File): Promise<ReconciliationResult> => {
    const tallyPart = await fileToGenerativePart(tallyFile);
    const bankPart = await fileToGenerativePart(bankFile);

    const prompt = `
        You are an expert financial analyst. Your task is to reconcile the two provided documents: a Tally statement and a bank statement.
        
        1.  Analyze both documents to extract all financial transactions. Identify the date, description/particulars, and amount for each entry.
        2.  Compare the transactions from both statements. A match occurs if the date and amount are very close or identical.
        3.  Categorize all transactions into three groups:
            - Matched Transactions: Present in both statements.
            - Tally Only Transactions: Present only in the Tally statement.
            - Bank Only Transactions: Present only in the bank statement.
        4.  Provide a summary of your findings.
        5.  Return the final output in the specified JSON format. Ensure all amounts are positive numbers.
    `;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: [
                {
                    parts: [
                        { text: prompt },
                        { text: "\n--- Tally Statement ---\n" },
                        tallyPart,
                        { text: "\n--- Bank Statement ---\n" },
                        bankPart,
                    ],
                },
            ],
            config: {
                responseMimeType: 'application/json',
                responseSchema: responseSchema,
            },
        });
        
        const jsonText = response.text;
        const result = JSON.parse(jsonText) as ReconciliationResult;
        return result;

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to reconcile statements. The AI model could not process the documents.");
    }
};
