
import React from 'react';
import { ReconciliationResult, Transaction } from '../types';
import ResultCard from './ResultCard';

interface ReconciliationViewProps {
  result: ReconciliationResult;
  onReset: () => void;
}

const StatCard: React.FC<{ title: string; value: string | number; color: string }> = ({ title, value, color }) => (
  <div className={`p-4 bg-white rounded-xl shadow-md border-t-4 ${color}`}>
    <p className="text-sm text-slate-500">{title}</p>
    <p className="text-2xl font-bold text-slate-800">{value}</p>
  </div>
);

const TransactionColumn: React.FC<{ title: string; transactions: Transaction[]; color: string }> = ({ title, transactions, color }) => (
  <div className="bg-slate-100 p-4 rounded-lg flex-1">
    <h3 className={`text-lg font-semibold mb-4 pb-2 border-b-2 ${color}`}>{title} ({transactions.length})</h3>
    {transactions.length > 0 ? (
      <div className="space-y-2">
        {transactions.map((tx, index) => (
          <ResultCard key={index} transaction={tx} />
        ))}
      </div>
    ) : (
      <div className="text-center py-10 text-slate-500">
        <p>No transactions found.</p>
      </div>
    )}
  </div>
);

const ReconciliationView: React.FC<ReconciliationViewProps> = ({ result, onReset }) => {
  const { summary, matchedTransactions, tallyOnlyTransactions, bankOnlyTransactions } = result;

  return (
    <div className="w-full max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Reconciliation Complete</h2>
        <button
          onClick={onReset}
          className="bg-slate-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-slate-700 transition-colors"
        >
          Start Over
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard title="Matched Transactions" value={summary.matchedCount} color="border-green-500" />
        <StatCard title="Total Matched Amount" value={new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(summary.totalMatchedAmount)} color="border-green-500" />
        <StatCard title="In Tally Only" value={summary.tallyOnlyCount} color="border-orange-500" />
        <StatCard title="In Bank Statement Only" value={summary.bankOnlyCount} color="border-blue-500" />
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        <TransactionColumn title="Matched Transactions" transactions={matchedTransactions} color="border-green-500 text-green-600" />
        <TransactionColumn title="In Tally Only" transactions={tallyOnlyTransactions} color="border-orange-500 text-orange-600" />
        <TransactionColumn title="In Bank Statement Only" transactions={bankOnlyTransactions} color="border-blue-500 text-blue-600" />
      </div>
    </div>
  );
};

export default ReconciliationView;
