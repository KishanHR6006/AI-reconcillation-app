
import React, { useRef } from 'react';
import CheckCircleIcon from './icons/CheckCircleIcon';
import DocumentIcon from './icons/DocumentIcon';

interface FileUploadProps {
  title: string;
  onFileSelect: (file: File) => void;
  selectedFile: File | null;
}

const FileUpload: React.FC<FileUploadProps> = ({ title, onFileSelect, selectedFile }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      onFileSelect(event.target.files[0]);
    }
  };

  const handleCardClick = () => {
    fileInputRef.current?.click();
  };
  
  const acceptedFormats = ".pdf, .xlsx, .xls, .png, .jpg, .jpeg";

  return (
    <div
      className="bg-white p-6 rounded-xl shadow-md border border-slate-200 hover:border-blue-500 transition-all duration-300 cursor-pointer"
      onClick={handleCardClick}
    >
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept={acceptedFormats}
      />
      <h3 className="text-lg font-semibold text-slate-700 mb-4">{title}</h3>
      {selectedFile ? (
        <div className="flex items-center space-x-3 text-green-600">
          <CheckCircleIcon className="w-8 h-8" />
          <div className="flex flex-col">
            <span className="font-medium text-slate-800">{selectedFile.name}</span>
            <span className="text-sm text-slate-500">{(selectedFile.size / 1024).toFixed(2)} KB</span>
          </div>
        </div>
      ) : (
        <div className="flex items-center space-x-3 text-slate-500">
          <DocumentIcon className="w-8 h-8" />
          <div className="flex flex-col">
            <span className="font-medium text-slate-800">Click to upload a file</span>
            <span className="text-sm">PDF, Excel, or Image</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileUpload;
