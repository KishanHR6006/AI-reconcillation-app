
import React from 'react';
import { Transaction } from '../types';

interface ResultCardProps {
  transaction: Transaction;
}

const ResultCard: React.FC<ResultCardProps> = ({ transaction }) => {
  const formattedAmount = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
  }).format(transaction.amount);

  return (
    <div className="bg-white p-3 rounded-lg border border-slate-200 grid grid-cols-3 gap-4 items-center">
      <p className="text-sm text-slate-600">{transaction.date}</p>
      <p className="text-sm text-slate-800 col-span-1 truncate">{transaction.description}</p>
      <p className="text-sm font-semibold text-slate-800 text-right">{formattedAmount}</p>
    </div>
  );
};

export default ResultCard;
